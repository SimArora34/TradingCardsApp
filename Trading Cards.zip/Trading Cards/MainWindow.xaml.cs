﻿using System.Security.Claims;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml.Linq;

namespace Trading_Cards
{
    public partial class MainWindow : Window
    {
        private List<Player> _players;

        public MainWindow()
        {
            InitializeComponent();
            _players = PlayerData.GetPlayers();
            PlayerList.ItemsSource = _players;
        }

        private void PlayerList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (PlayerList.SelectedItem is Player selectedPlayer)
            {
                PlayerName.Text = selectedPlayer.Name;
                PlayerPhoto.Source = new BitmapImage(new Uri(selectedPlayer.PhotoPath, UriKind.RelativeOrAbsolute));
                PlayerStats.Text = $"Games Played: {selectedPlayer.GamesPlayed}\nGoals: {selectedPlayer.Goals}\nAssists: {selectedPlayer.Assists}\nRating: {selectedPlayer.Rating}";
                CardBorder.Background = selectedPlayer.Team == "TeamA" ? Brushes.Blue : Brushes.Red;
            }
        }
    }
}
















