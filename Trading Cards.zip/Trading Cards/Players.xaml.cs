﻿public class Player
{
    public string Name { get; set; }
    public string Team { get; set; }
    public string PhotoPath { get; set; }
    public int GamesPlayed { get; set; }
    public int Goals { get; set; }
    public int Assists { get; set; }
    public double Rating { get; set; }
}


public static class PlayerData
{
    public static List<Player> GetPlayers()
    {
        return new List<Player>
        {
            new Player { Name = "Player1", Team = "TeamA", PhotoPath = "path/to/photo1.jpg", GamesPlayed = 20, Goals = 10, Assists = 5, Rating = 8.5 },
            new Player { Name = "Player2", Team = "TeamB", PhotoPath = "path/to/photo2.jpg", GamesPlayed = 18, Goals = 12, Assists = 6, Rating = 9.0 },
            // Add more players
        };
    }
}

